package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import fase.uno.mundo.real.entidades.encapsulamiento.clientes.Cliente;
import fase.uno.mundo.real.entidades.encapsulamiento.clientes.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)

public class CuentaConvertibilidad extends CuentaCorriente {

    private double saldoDolares;

    public CuentaConvertibilidad(int nroCuenta, Cliente cliente, double montoAutorizado, double saldoDolares) {
        super(nroCuenta, cliente, montoAutorizado);
        if (!(cliente instanceof ClienteEmpresa)) {
            throw new IllegalArgumentException("Lo siento pero la cuenta convertibilidad solo puede aceptar los de cliente empresa");
        }
        this.saldoDolares = saldoDolares;
    }

    /**
     * Deposita dólares en la Cuenta Convertiilidad
     * El monto a depositar debe ser mayor que cero, caso contrario dara ERROR
     *
     * @param monto -> cantidad de dólares que se desea depositar
     */
    public void depositarDolares(double monto) {
        if (monto > 0) {
            saldoDolares += monto;
            System.out.println("Se a depositado: U$D" + monto + " exitosamente");
        } else
            System.out.println("Lo sentimos pero la cantidad depositada es incorrecta");
    }

    /**
     * Extrae dólares de la Cuenta Corriente
     * La extracción solo se realiza únicamente si el monto es mayor a cero y no
     * supera el saldo disponible en dólares
     *
     * @param monto -> cantidad de dólares que se desea o puede extraer
     * @return true -> solo si la extraccion es realisada con exito, en caso contrario le saldra fondos insuficientes o monto incorrecto
     */
    public boolean extraerDolares(double monto) {
        if (monto > 0 && monto <= saldoDolares) {
            saldoDolares -= monto;
            System.out.println("Se retiro: U$D" + monto + " exitosamente | Saldo restante: U$D" + getSaldoDolares());
            return true;
        }
        System.out.println("Fondos insuficientes");
        return false;
    }

    /**
     * Convierte de Pesos a Dolares
     * La conversión se realiza solamente si el monto y la tasa son mayores a cero
     *
     * @param montoPesos -> cantidad de pesos que se desea convertir.
     * @param tasa -> tasa de conversión de pesos a dólares.
     * @return -> cantidad de dólares obtenida despues de realizar la conversión, retorna 0 si el monto, la tasa o el saldo llegan a ser insuficientes.
     */
    public double convertirPesosADolares(double montoPesos, double tasa) {
        if (montoPesos <= 0 || tasa <= 0) {
            System.out.println("El monto o tasa no son incorrecto");
            return 0;
        }
        if (montoPesos > getSaldo()) {
            System.out.println("Saldo insuficiente en pesos");
            return 0;
        }
        double dolares = montoPesos / tasa;
        setSaldo(getSaldo() - montoPesos);
        saldoDolares += dolares;
        System.out.println("Conversión realizada: $" + montoPesos + " -> U$D" + dolares);
        return dolares;
    }

    /**
     * Convierte de Dolares a Pesos
     * La conversión se realiza solamente si el monto y la tasa son mayores a cero
     *
     * @param montoDolares -> cantidad de dólares que se desea convertir.
     * @param tasa -> tasa de conversión de dólares a pesos.
     * @return -> cantidad de pesos obtenida luego de realizar la conversión, retorna 0 si el monto, la tasa o el saldo llegan a ser insuficientes.
     */
    public double convertirDolaresAPesos(double montoDolares, double tasa) {
        if (montoDolares <= 0 || tasa <= 0) {
            System.out.println("El monto o tasa no son incorrecto");
            return 0;
        }
        if (montoDolares > saldoDolares) {
            System.out.println("Saldo insuficiente en dólares");
            return 0;
        }
        double pesos = montoDolares * tasa;
        saldoDolares -= montoDolares;
        setSaldo(getSaldo() + pesos);
        System.out.println("Conversión realizada: U$D" + montoDolares + " -> $" + pesos);
        return pesos;
    }
}
