package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import fase.uno.mundo.real.entidades.encapsulamiento.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)

public class CajaDeAhorro extends Cuenta {

    private double tasaInteres;

    public CajaDeAhorro(int nroCuenta, Cliente cliente, double tasaInteres) {
        super(nroCuenta, cliente);
        this.tasaInteres = tasaInteres;
    }

    /**
     * Extraer efectivo en Caja de Ahorro:
     * Las extracciónes se realiza solamente si el monto es mayor a cero y no supera el saldo
     * que tiene disponible, de lo contrario la operacion no se realizara con exito
     * 
     * @param monto -> cantidad de dinero que deseas extraer, no se admiten numeros negativos
     * @return true -> solo si la extraccion es realisada con exito, en caso
     *         contrario le saldra fondos insuficientes o monto incorrecto
     */
    @Override
    public boolean extraerEfectivo(double monto) {
        if (monto > 0 && monto <= getSaldo()) {
            setSaldo(getSaldo() - monto);
            System.out.println("Se retiro: $" + monto + " exitosamente, le quedan $" + getSaldo());
            return true;
        }
        System.out.println("Fondos insuficientes");
        return false;
    }

    /**
     * Cobrar interes:
     * Calcula y cobra los intereses de la Caja de Ahorro, esto se calcula utilizando la
     * tasa de interes mas el saldo disponible
     * 
     * @return interes -> devuelve el interes generado mas el sueldo
     */
    public double cobrarInteres() {
        double interes = getSaldo() * (tasaInteres / 100); 
        double saldoTotal = getSaldo() + interes;
        setSaldo(saldoTotal);
        System.out.println("Su tasa de intesres es de: " + tasaInteres + "%");
        System.out.println("Su saldo total es: $" + saldoTotal);
        return interes;
    }

}
