package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import fase.uno.mundo.real.entidades.encapsulamiento.clientes.Cliente;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@RequiredArgsConstructor

public abstract class Cuenta {

    private final int nroCuenta;
    private final Cliente cliente;
    private double saldo;

    public abstract void depositarEfectivo(double monto);

    public abstract boolean extraerEfectivo(double monto);

}
