package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import fase.uno.mundo.real.entidades.encapsulamiento.clientes.Cliente;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@RequiredArgsConstructor

public abstract class Cuenta {

    private final int nroCuenta;
    private final Cliente cliente;
    private double saldo;

      /**
     * Depositar efectivo en Caja de Ahorro:
     * Monto a depositar debe ser mayor a cero.
     * 
     * @param monto -> cantidad de dinero que deseas depositar, no se admiten numeros negativos
     */
    public void depositarEfectivo(double monto) {
        if (monto > 0) {
            setSaldo(getSaldo() + monto);
            System.out.println("Se deposito: $" + monto + " exitosamente");
        } else
            System.out.println("Lo sentimo pero la cantidad depositada es incorrecta");
    }


    public abstract boolean extraerEfectivo(double monto);

}
