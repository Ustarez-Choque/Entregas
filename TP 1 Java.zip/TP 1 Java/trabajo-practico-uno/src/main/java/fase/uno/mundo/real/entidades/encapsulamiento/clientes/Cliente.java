package fase.uno.mundo.real.entidades.encapsulamiento.clientes;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString

public abstract class Cliente {

    private int idCliente;

    public Cliente(int idCliente) {
        this.idCliente = idCliente;
    }

}
