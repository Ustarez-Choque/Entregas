package fase.uno.mundo.real.entidades.encapsulamiento.clientes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor 

public abstract class Cliente {

    private int idCliente;

}
