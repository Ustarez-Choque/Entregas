package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import fase.uno.mundo.real.entidades.encapsulamiento.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)

public class CuentaCorriente extends Cuenta {

    private double montoAutorizado;

    public CuentaCorriente(int nroCuenta, Cliente cliente, double montoAutorizado) {
        super(nroCuenta, cliente);
        this.montoAutorizado = montoAutorizado;
    }

    /**
     * Deposita efectivo en la Cuenta Corriente:
     * Monto a depositar debe ser mayor a cero
     *
     * @param monto -> cantidad de dinero que deseas depositar, no se admiten numeros negativos
     */
    @Override
    public void depositarEfectivo(double monto) {
        if (monto > 0) {
            setSaldo(getSaldo() + monto);
            System.out.println("Se deposito: $" + monto + " exitosamente");
        } else {
            System.out.println("Lo sentimos pero la cantidad depositada es incorrecta");
        }
    }

    /**
     * Extraer efectivo de la Cuenta Corriente:
     * El cliente solamente puede extrar efectivo utilizando mas el monto autorizado 
     * siempre y cuando tenga saldo disponible y no supere el monto total
     *
     * @param monto -> cantidad de dinero que se desea extraer
     * @return true -> si la extracción fue realizada, false si supera el saldo disponible más el monto autorizado.
     */
    @Override
    public boolean extraerEfectivo(double monto) {
        if (monto > 0 && monto <= getSaldo() + montoAutorizado) {
            setSaldo(getSaldo() - monto);
            System.out.println("Se retiro: $" + monto + " exitosamente | Saldo restante: $" + getSaldo());
            return true;
        }
        System.out.println("No se pudo realizar la extracción");
        return false;
    }

    /**
     * Deposita Cheque en la Cuenta Corriente
     * El cheque debera existir y tener un monto mayor que cero para que el deposito
     * sea exitoso
     *
     * @param cheque -> cheque que se desea depositar en el Banco
     */
    public void depositarCheque(Cheque cheque) {
        if (cheque == null) {
            System.out.println("ERROR: No se a encontrado cheque");
        } else if (cheque.getMonto() <= 0) {
            System.out.println("Lo siento el monto del cheque debe ser mayor a 0");
        } else {
            setSaldo(getSaldo() + cheque.getMonto());
            System.out.println("Cheque depositado: $" + cheque.getMonto() + " con exito, del Banco: " + cheque.getBancoEmisor());
        }
    }
}
