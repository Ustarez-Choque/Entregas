package fase.uno.mundo.real.entidades.encapsulamiento.clientes;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString

public class ClienteEmpresa extends Cliente {

    private String nombreFantacia, cuit;

    public ClienteEmpresa(int idCliente, String nombreFantacia, String cuit) {
        super(idCliente);
        this.nombreFantacia = nombreFantacia;
        this.cuit = cuit;
    }

}
