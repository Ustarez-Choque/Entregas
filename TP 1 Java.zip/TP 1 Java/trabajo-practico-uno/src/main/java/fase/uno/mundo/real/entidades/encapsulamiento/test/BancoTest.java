package fase.uno.mundo.real.entidades.encapsulamiento.test;

import java.util.ArrayList;

import fase.uno.mundo.real.entidades.encapsulamiento.clientes.Cliente;
import fase.uno.mundo.real.entidades.encapsulamiento.clientes.ClienteEmpresa;
import fase.uno.mundo.real.entidades.encapsulamiento.clientes.ClienteIndividual;
import fase.uno.mundo.real.entidades.encapsulamiento.cuentas.CajaDeAhorro;
import fase.uno.mundo.real.entidades.encapsulamiento.cuentas.Cheque;
import fase.uno.mundo.real.entidades.encapsulamiento.cuentas.Cuenta;
import fase.uno.mundo.real.entidades.encapsulamiento.cuentas.CuentaConvertibilidad;
import fase.uno.mundo.real.entidades.encapsulamiento.cuentas.CuentaCorriente;

public class BancoTest {
    public static void main(String[] args) {

        ArrayList<Cliente> clientes = new ArrayList<>();
        ArrayList<Cuenta> cuentas = new ArrayList<>();

        System.out.println("\n ===== Clientes ===== \n");

        ClienteIndividual individual = new ClienteIndividual(101, "Mi", "Kasa", "42587963");
        ClienteIndividual individual2 = new ClienteIndividual(201, "Eren", "Jaeger", "42698713");
        System.out.println(individual);
        System.out.println(individual2);

        ClienteEmpresa empresa = new ClienteEmpresa(111, "Peppita Pig", "20-45793861-9");
        ClienteEmpresa empresa2 = new ClienteEmpresa(211, "Raton Perez", "20-45879632-1");
        System.out.println(empresa);
        System.out.println(empresa2);

        clientes.add(individual);
        clientes.add(individual2);
        clientes.add(empresa);
        clientes.add(empresa2);

        System.out.println("\n ===== Cuentas ===== \n");

        CajaDeAhorro caja = new CajaDeAhorro(550, individual, 21.5);
        System.out.println(caja);
        CuentaCorriente corriente = new CuentaCorriente(600, empresa, 15000);
        System.out.println(corriente);
        CuentaConvertibilidad convertibilidad = new CuentaConvertibilidad(650, empresa2, 12000, 0);
        System.out.println(convertibilidad);

        cuentas.add(caja);
        cuentas.add(corriente);
        cuentas.add(convertibilidad);

        System.out.println("\n ===== Caja de Ahorro ===== \n");

        System.out.println("Cuenta del cliente: " + caja.getCliente());
        System.out.println("Saldo inicial: $" + caja.getSaldo());

        caja.depositarEfectivo(120000);
        System.out.println("Su saldo ahorra es: $" + caja.getSaldo());

        caja.extraerEfectivo(20000);
        caja.cobrarInteres();

        System.out.println("\n ===== Cuenta Corriente ===== \n");

        System.out.println("Cuenta del cliente: " + corriente.getCliente());
        System.out.println("Saldo inicial: $" + corriente.getSaldo());

        corriente.depositarEfectivo(255000);
        System.out.println("Su saldo ahorra es: $" + corriente.getSaldo());

        corriente.extraerEfectivo(36520);
        System.out.println("Monto maximo autorizado es: $" + corriente.getMontoAutorizado());
        corriente.extraerEfectivo(228480);
        System.out.println("Felicidades eres pobre y estas endeudado. Su saldo es: $" + corriente.getSaldo());

        System.out.println("\n ===== Cuenta Corriente en Cheque ===== \n");

        Cheque cheque = new Cheque(16590, "Credicoop", "15-09-2026");
        System.out.println("Cheque de la cuenta: " + corriente.getCliente());
        corriente.depositarCheque(cheque);
        System.out.println("Su saldo paso a ser: $" + corriente.getSaldo());
        corriente.depositarCheque(null);
        System.out.println("Su saldo paso a ser: $" + corriente.getSaldo());

        System.out.println("\n ===== Cuenta Convertibilidad ===== \n");

        System.out.println("\n ===== Depositar =====");
        System.out.println("Cuenta del cliente: " + convertibilidad.getCliente());
        System.out.println("Saldo en Pesos: $" + convertibilidad.getSaldo());
        System.out.println("Saldo en Dolares: U$D" + convertibilidad.getSaldoDolares());
        convertibilidad.depositarEfectivo(120000);
        convertibilidad.depositarDolares(500);

        System.out.println("\n ===== Extraer =====");
        System.out.println("Saldo actual: $" + convertibilidad.getSaldo());
        convertibilidad.extraerEfectivo(6500);
        System.out.println("Saldo actual: U$D" + convertibilidad.getSaldoDolares());
        convertibilidad.extraerDolares(325);

        System.out.println("\n ===== Convercion de Pesos a Dolares =====");
        double dolares = convertibilidad.convertirPesosADolares(10000, 5);
        System.out.println("Tienes U$D" + dolares);

        System.out.println("\n ===== Convercion de Dolares a Pesos =====");
        double pesos = convertibilidad.convertirDolaresAPesos(200, 5);
        System.out.println("Tienes $" + pesos);

        System.out.println("\n ===== Clientes con Cuentas =====");
        System.out.println("La cuenta: " + caja.getNroCuenta() + " le pertenece a " + caja.getCliente());
        System.out.println("La cuenta: " + corriente.getNroCuenta() + " le pertenece a " + corriente.getCliente());
        System.out.println("La cuenta: " + convertibilidad.getNroCuenta() + " le pertenece a " + convertibilidad.getCliente());

        System.out.println("\n ===== Test de Verificacion =====");
        ClienteEmpresa emp = new ClienteEmpresa(1001, "Jorge El Curioso", "20-4597813684-3");
        ClienteIndividual ind = new ClienteIndividual(2010, "Optimus", "Prime", "AS45FS44");
        System.out.println(emp);
        System.out.println(ind);
        // Restriccion forzada vista en clase, la Cuente Convertibilidad puede ser creada por cualquier cliente pero al momento de la ejecucion
        // se rompe ya que solo admitira a Clientes Empresa y no a los Clientes Individuales
        
        /* CuentaConvertibilidad conver = new CuentaConvertibilidad(0, ind, pesos, dolares);
        System.out.println(conver); */
        
        CuentaConvertibilidad conver2 = new CuentaConvertibilidad(0, emp, pesos, dolares);
        System.out.println(conver2);

    }
}
