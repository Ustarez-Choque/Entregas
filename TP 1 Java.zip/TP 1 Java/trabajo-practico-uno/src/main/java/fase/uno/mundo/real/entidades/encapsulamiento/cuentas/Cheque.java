package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 
@RequiredArgsConstructor 

public class Cheque {

    private final String bancoEmisor;
    private final String fechaDePago;
    private final double monto;

}
