package fase.uno.mundo.real.entidades.encapsulamiento.cuentas;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 

public class Cheque {

    private double monto;
    private String bancoEmisor;
    private String fechaDePago;

    public Cheque(double monto, String bancoEmisor, String fechaDePago) {
        this.monto = monto;
        this.bancoEmisor = bancoEmisor;
        this.fechaDePago = fechaDePago;
    }   

}
