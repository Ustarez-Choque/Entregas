package fase.uno.mundo.real;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoPracticoUnoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoPracticoUnoApplication.class, args);
	}

}
