package fase.uno.mundo.real.entidades.encapsulamiento.clientes;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString (callSuper = true)

public class ClienteIndividual extends Cliente {

    private String nombre, apellido, dni;

    public ClienteIndividual(int idCliente, String nombre, String apellido, String dni) {
        super(idCliente);
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
    }

}
