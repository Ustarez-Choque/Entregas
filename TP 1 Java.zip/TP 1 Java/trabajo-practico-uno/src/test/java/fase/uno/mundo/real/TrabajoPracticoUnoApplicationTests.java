package fase.uno.mundo.real;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoPracticoUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
